﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusTag_01
{
    /// <summary>
    /// Login.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtId.Text == "abcd" && txtPw.Password == "1234")
            {
                MessageBox.Show("직원 로그인 확인되었습니다.", "로그인 성공");
                Attendance attendance = new Attendance();
                attendance.Show();
                //this.Close();
            }
            else
                MessageBox.Show("로그인 정보가 일치하지 않습니다.", "로그인 실패");
                txtId.Text = string.Empty;
                txtPw.Password = string.Empty;  

        }
    }
}
