﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusTag_01
{
    /// <summary>
    /// Attendance.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Attendance : Window
    {
        public Attendance()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Insert insert = new Insert();
            insert.Show();
            this.Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("정말 000 아이의 정보를 삭제하시겠습니까?", "정보삭제", MessageBoxButton.YesNo, MessageBoxImage.Warning );
            //Firebase 이용해서 id에ㅔ 접근해 정보를 삭제 -> C# 화면에서 아이의 정보가 삭제돼야함
        }
    }
}
